```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
```


```python
# Charger le fichier Excel
df = pd.read_excel('supply chain retail.xlsx', engine='openpyxl')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Commandes_Totales</th>
      <th>Commandes_Livrees_A_Temps</th>
      <th>Délai_Livraison</th>
      <th>Stock_Available</th>
      <th>Stock_Used</th>
      <th>Coût_Transport</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2024-01-01</td>
      <td>106</td>
      <td>135</td>
      <td>4</td>
      <td>733</td>
      <td>312</td>
      <td>2974</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2024-01-02</td>
      <td>126</td>
      <td>141</td>
      <td>4</td>
      <td>551</td>
      <td>263</td>
      <td>2889</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2024-01-03</td>
      <td>102</td>
      <td>128</td>
      <td>4</td>
      <td>758</td>
      <td>332</td>
      <td>2041</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2024-01-04</td>
      <td>177</td>
      <td>94</td>
      <td>3</td>
      <td>904</td>
      <td>590</td>
      <td>2033</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2024-01-05</td>
      <td>130</td>
      <td>99</td>
      <td>5</td>
      <td>845</td>
      <td>278</td>
      <td>2935</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (50, 7)




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Commandes_Totales</th>
      <th>Commandes_Livrees_A_Temps</th>
      <th>Délai_Livraison</th>
      <th>Stock_Available</th>
      <th>Stock_Used</th>
      <th>Coût_Transport</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2024-01-01</td>
      <td>106</td>
      <td>135</td>
      <td>4</td>
      <td>733</td>
      <td>312</td>
      <td>2974</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2024-01-02</td>
      <td>126</td>
      <td>141</td>
      <td>4</td>
      <td>551</td>
      <td>263</td>
      <td>2889</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2024-01-03</td>
      <td>102</td>
      <td>128</td>
      <td>4</td>
      <td>758</td>
      <td>332</td>
      <td>2041</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2024-01-04</td>
      <td>177</td>
      <td>94</td>
      <td>3</td>
      <td>904</td>
      <td>590</td>
      <td>2033</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2024-01-05</td>
      <td>130</td>
      <td>99</td>
      <td>5</td>
      <td>845</td>
      <td>278</td>
      <td>2935</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    Date                         0
    Commandes_Totales            0
    Commandes_Livrees_A_Temps    0
    Délai_Livraison              0
    Stock_Available              0
    Stock_Used                   0
    Coût_Transport               0
    dtype: int64




```python
# Convertir les dates en format DateTime
df['Date'] = pd.to_datetime(df['Date'])
```


```python
# Analyse desciptive du jeu de données
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Commandes_Totales</th>
      <th>Commandes_Livrees_A_Temps</th>
      <th>Délai_Livraison</th>
      <th>Stock_Available</th>
      <th>Stock_Used</th>
      <th>Coût_Transport</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>50</td>
      <td>50.000000</td>
      <td>50.000000</td>
      <td>50.000000</td>
      <td>50.000000</td>
      <td>50.000000</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2024-01-25 12:00:00</td>
      <td>153.800000</td>
      <td>114.200000</td>
      <td>4.300000</td>
      <td>778.900000</td>
      <td>378.380000</td>
      <td>2310.560000</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2024-01-01 00:00:00</td>
      <td>102.000000</td>
      <td>75.000000</td>
      <td>3.000000</td>
      <td>503.000000</td>
      <td>200.000000</td>
      <td>1532.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2024-01-13 06:00:00</td>
      <td>129.000000</td>
      <td>100.000000</td>
      <td>3.250000</td>
      <td>679.750000</td>
      <td>278.000000</td>
      <td>2019.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2024-01-25 12:00:00</td>
      <td>160.000000</td>
      <td>113.000000</td>
      <td>4.000000</td>
      <td>796.000000</td>
      <td>338.500000</td>
      <td>2263.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2024-02-06 18:00:00</td>
      <td>179.750000</td>
      <td>131.250000</td>
      <td>5.000000</td>
      <td>898.000000</td>
      <td>490.500000</td>
      <td>2640.250000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2024-02-19 00:00:00</td>
      <td>196.000000</td>
      <td>144.000000</td>
      <td>6.000000</td>
      <td>982.000000</td>
      <td>590.000000</td>
      <td>2984.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>29.048165</td>
      <td>18.255555</td>
      <td>1.035098</td>
      <td>140.659707</td>
      <td>123.470543</td>
      <td>403.086113</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Relation entre les variables quantitatives

sns.pairplot(df)
```




    <seaborn.axisgrid.PairGrid at 0x203ed2f5dc0>




    
![png](output_8_1.png)
    



```python
# Calculer le taux de service client
df['Taux_Service_Client'] = (df['Commandes_Livrees_A_Temps'] / df['Commandes_Totales']) * 100
```


```python
# Afficher les premières lignes pour vérifier le calcul
print(df[['Date', 'Taux_Service_Client']].head())
```

            Date  Taux_Service_Client
    0 2024-01-01           127.358491
    1 2024-01-02           111.904762
    2 2024-01-03           125.490196
    3 2024-01-04            53.107345
    4 2024-01-05            76.153846
    


```python
# Visualiser le taux de service client au fil du temps
plt.figure(figsize=(10, 6))
plt.plot(df['Date'], df['Taux_Service_Client'], marker='o')
plt.title('Taux de Service Client')
plt.xlabel('Date')
plt.ylabel('Taux de Service Client (%)')
plt.xticks(rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()

```


    
![png](output_11_0.png)
    



```python
# Ajoutons des colonnes pour le mois et l'année
df['Mois'] = df['Date'].dt.to_period('M')
df['Année'] = df['Date'].dt.year
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Commandes_Totales</th>
      <th>Commandes_Livrees_A_Temps</th>
      <th>Délai_Livraison</th>
      <th>Stock_Available</th>
      <th>Stock_Used</th>
      <th>Coût_Transport</th>
      <th>Taux_Service_Client</th>
      <th>Mois</th>
      <th>Année</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2024-01-01</td>
      <td>106</td>
      <td>135</td>
      <td>4</td>
      <td>733</td>
      <td>312</td>
      <td>2974</td>
      <td>127.358491</td>
      <td>2024-01</td>
      <td>2024</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2024-01-02</td>
      <td>126</td>
      <td>141</td>
      <td>4</td>
      <td>551</td>
      <td>263</td>
      <td>2889</td>
      <td>111.904762</td>
      <td>2024-01</td>
      <td>2024</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2024-01-03</td>
      <td>102</td>
      <td>128</td>
      <td>4</td>
      <td>758</td>
      <td>332</td>
      <td>2041</td>
      <td>125.490196</td>
      <td>2024-01</td>
      <td>2024</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2024-01-04</td>
      <td>177</td>
      <td>94</td>
      <td>3</td>
      <td>904</td>
      <td>590</td>
      <td>2033</td>
      <td>53.107345</td>
      <td>2024-01</td>
      <td>2024</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2024-01-05</td>
      <td>130</td>
      <td>99</td>
      <td>5</td>
      <td>845</td>
      <td>278</td>
      <td>2935</td>
      <td>76.153846</td>
      <td>2024-01</td>
      <td>2024</td>
    </tr>
  </tbody>
</table>
</div>



Calculons les Moyennes Mensuelles et Annuelles


```python
# Moyenne mensuelle du taux de service client
df_mensuel = df.groupby('Mois')['Taux_Service_Client'].mean().reset_index()

# Moyenne annuelle du taux de service client
df_annuel = df.groupby('Année')['Taux_Service_Client'].mean().reset_index()

```


```python
# Afficher la moyenne mensuelle du taux de service client
print("Moyenne Mensuelle du Taux de Service Client :")
print(df_mensuel)

# Afficher la moyenne annuelle du taux de service client
print("\nMoyenne Annuelle du Taux de Service Client :")
print(df_annuel)

```

    Moyenne Mensuelle du Taux de Service Client :
          Mois  Taux_Service_Client
    0  2024-01            76.631917
    1  2024-02            74.628031
    
    Moyenne Annuelle du Taux de Service Client :
       Année  Taux_Service_Client
    0   2024             75.87044
    

Graphique Mensuel


```python
# Visualisation les moyennes mensuelles du taux de service client
plt.figure(figsize=(12, 6))
plt.plot(df_mensuel['Mois'].astype(str), df_mensuel['Taux_Service_Client'], marker='o', linestyle='-', color='b')
plt.title('Moyenne Mensuelle du Taux de Service Client')
plt.xlabel('Mois')
plt.ylabel('Taux de Service Client (%)')
plt.xticks(rotation=45)  # Rotation des labels des mois pour une meilleure lisibilité
plt.grid(True)
plt.tight_layout()
plt.show()
```


    
![png](output_18_0.png)
    


Graphique Annuel


```python
# Visualisons les moyennes annuelles du taux de service client
plt.figure(figsize=(12, 6))
plt.plot(df_annuel['Année'], df_annuel['Taux_Service_Client'], marker='o', linestyle='-', color='g')
plt.title('Moyenne Annuelle du Taux de Service Client')
plt.xlabel('Année')
plt.ylabel('Taux de Service Client (%)')
plt.grid(True)
plt.tight_layout()
plt.show()
```


    
![png](output_20_0.png)
    


 Analyse des Tendances


```python
df_mensuel['Mois'] = df_mensuel['Mois'].dt.to_timestamp()
```


```python

# Visualiser les moyennes mensuelles du taux de service client
plt.figure(figsize=(12, 6))
plt.plot(df_mensuel['Mois'], df_mensuel['Taux_Service_Client'], marker='o', linestyle='-', color='b')
plt.title('Moyenne Mensuelle du Taux de Service Client')
plt.xlabel('Mois')
plt.ylabel('Taux de Service Client (%)')
plt.xticks(rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()
```


    
![png](output_23_0.png)
    


 Identifions les Périodes de Performances Particulièrement Bonnes ou Mauvaises


```python
# Trouver les mois avec les meilleures et les pires performances
meilleure_performance_mois = df_mensuel.loc[df_mensuel['Taux_Service_Client'].idxmax()]
pire_performance_mois = df_mensuel.loc[df_mensuel['Taux_Service_Client'].idxmin()]

print("Meilleure Performance Mensuelle:")
print(meilleure_performance_mois)

print("\nPire Performance Mensuelle:")
print(pire_performance_mois)
```

    Meilleure Performance Mensuelle:
    Mois                   2024-01-01 00:00:00
    Taux_Service_Client              76.631917
    Name: 0, dtype: object
    
    Pire Performance Mensuelle:
    Mois                   2024-02-01 00:00:00
    Taux_Service_Client              74.628031
    Name: 1, dtype: object
    

analyser les différentes composantes d'une série temporelle


```python
from statsmodels.tsa.seasonal import seasonal_decompose

# Décomposer les séries temporelles
df.set_index('Date', inplace=True)
decomposition = seasonal_decompose(df['Taux_Service_Client'], model='additive')

# Visualiser la décomposition
plt.figure(figsize=(14, 10))
plt.subplot(4, 1, 1)
plt.plot(decomposition.observed)
plt.title('Observé')

plt.subplot(4, 1, 2)
plt.plot(decomposition.trend)
plt.title('Tendance')

plt.subplot(4, 1, 3)
plt.plot(decomposition.seasonal)
plt.title('Saisonnier')

plt.subplot(4, 1, 4)
plt.plot(decomposition.resid)
plt.title('Résidu')

plt.tight_layout()
plt.show()

```


    
![png](output_27_0.png)
    


 Calcul des Délais de Livraison


```python

# Exemple de données
data = {
    'Date_Commande': ['2024-07-01', '2024-07-03', '2024-07-05', '2024-07-10', '2024-07-12'],
    'Date_Livraison': ['2024-07-06', '2024-07-08', '2024-07-10', '2024-07-15', '2024-07-18'],
    'Commandes_Totales': [100, 150, 200, 250, 300],
    'Commandes_Livrees_A_Temps': [95, 140, 190, 240, 290]
}

# Création du DataFrame initial
df1 = pd.DataFrame(data)

# Convertir les dates en format DateTime
df1['Date_Commande'] = pd.to_datetime(df1['Date_Commande'])
df1['Date_Livraison'] = pd.to_datetime(df1['Date_Livraison'])

# Calculer le délai de livraison en jours
df1['Delai_Livraison'] = (df1['Date_Livraison'] - df1['Date_Commande']).dt.days

# Renommer le DataFrame de df à df1
df1 = df1.copy()

# Afficher le DataFrame df1 pour vérifier
print(df1)

```

      Date_Commande Date_Livraison  Commandes_Totales  Commandes_Livrees_A_Temps  \
    0    2024-07-01     2024-07-06                100                         95   
    1    2024-07-03     2024-07-08                150                        140   
    2    2024-07-05     2024-07-10                200                        190   
    3    2024-07-10     2024-07-15                250                        240   
    4    2024-07-12     2024-07-18                300                        290   
    
       Delai_Livraison  
    0                5  
    1                5  
    2                5  
    3                5  
    4                6  
    

5. Analyse des Causes des Retards
Examine les données pour identifier les patterns de retard, comme par région ou type de produit si ces informations sont disponibles.


```python
regions = ['Nord', 'Sud', 'Nord', 'Ouest', 'Est'] * (len(df1) // 5) + ['Nord', 'Sud', 'Nord', 'Ouest', 'Est'][:len(df) % 5]
df1['Région'] = regions

```


```python
#Attribuer une seule valeur à toutes les lignes
#Si vous voulez attribuer une seule région à toutes les lignes, vous pouvez le faire en une seule instruction
df1['Région'] = 'Nord'

```


```python
#Utiliser des valeurs aléatoires pour remplir la colonne
#Si vous voulez attribuer aléatoirement une des régions à chaque ligne
import numpy as np

df1['Région'] = np.random.choice(['Nord', 'Sud', 'Ouest', 'Est'], size=len(df1))
```


```python
# Manuellement définir les valeurs
#Si vous voulez spécifier manuellement les régions pour les premières 5 lignes et laisser les autres valeurs vides ou en les remplissant par une valeur spécifique
df1['Région'] = ['Nord', 'Sud', 'Nord', 'Ouest', 'Est'] + ['Valeur par défaut'] * (len(df1) - 5)

```


```python
#Après avoir ajouté la colonne Région, vous pouvez relancer votre analyse par région 
df1_region = df1.groupby('Région')['Delai_Livraison'].describe()
print(df1_region)

```

            count  mean  std  min  25%  50%  75%  max
    Région                                           
    Est       1.0   6.0  NaN  6.0  6.0  6.0  6.0  6.0
    Nord      2.0   5.0  0.0  5.0  5.0  5.0  5.0  5.0
    Ouest     1.0   5.0  NaN  5.0  5.0  5.0  5.0  5.0
    Sud       1.0   5.0  NaN  5.0  5.0  5.0  5.0  5.0
    


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date_Commande</th>
      <th>Date_Livraison</th>
      <th>Commandes_Totales</th>
      <th>Commandes_Livrees_A_Temps</th>
      <th>Delai_Livraison</th>
      <th>Région</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2024-07-01</td>
      <td>2024-07-06</td>
      <td>100</td>
      <td>95</td>
      <td>5</td>
      <td>Nord</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2024-07-03</td>
      <td>2024-07-08</td>
      <td>150</td>
      <td>140</td>
      <td>5</td>
      <td>Sud</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2024-07-05</td>
      <td>2024-07-10</td>
      <td>200</td>
      <td>190</td>
      <td>5</td>
      <td>Nord</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2024-07-10</td>
      <td>2024-07-15</td>
      <td>250</td>
      <td>240</td>
      <td>5</td>
      <td>Ouest</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2024-07-12</td>
      <td>2024-07-18</td>
      <td>300</td>
      <td>290</td>
      <td>6</td>
      <td>Est</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Exemple de données
data = {
    'Région': ['Nord', 'Sud', 'Est', 'Ouest', 'Nord', 'Sud', 'Est', 'Ouest'],
    'Delai_Livraison': [5, 6, 7, 5, 6, 4, 6, 5]
}

```


```python
df = pd.DataFrame(data)

# Vérifier les colonnes
print(df.columns)
```

    Index(['Région', 'Delai_Livraison'], dtype='object')
    


```python
print(df.head())  # Affiche les premières lignes du DataFrame

```

      Région  Delai_Livraison
    0   Nord                5
    1    Sud                6
    2    Est                7
    3  Ouest                5
    4   Nord                6
    


```python
# Créer un graphique en barres
plt.figure(figsize=(10, 6))
df.groupby('Région')['Delai_Livraison'].mean().plot(kind='bar', color='skyblue')

# Ajouter des labels et un titre
plt.xlabel('Région')
plt.ylabel('Délai de Livraison (jours)')
plt.title('Délai de Livraison Moyen par Région')
plt.xticks(rotation=0)

# Afficher le graphique
plt.show()
```


    
![png](output_40_0.png)
    



```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Région</th>
      <th>Delai_Livraison</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Nord</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Sud</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Est</td>
      <td>7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Ouest</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nord</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
df1.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date_Commande</th>
      <th>Date_Livraison</th>
      <th>Commandes_Totales</th>
      <th>Commandes_Livrees_A_Temps</th>
      <th>Delai_Livraison</th>
      <th>Région</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2024-07-01</td>
      <td>2024-07-06</td>
      <td>100</td>
      <td>95</td>
      <td>5</td>
      <td>Nord</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2024-07-03</td>
      <td>2024-07-08</td>
      <td>150</td>
      <td>140</td>
      <td>5</td>
      <td>Sud</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2024-07-05</td>
      <td>2024-07-10</td>
      <td>200</td>
      <td>190</td>
      <td>5</td>
      <td>Nord</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2024-07-10</td>
      <td>2024-07-15</td>
      <td>250</td>
      <td>240</td>
      <td>5</td>
      <td>Ouest</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2024-07-12</td>
      <td>2024-07-18</td>
      <td>300</td>
      <td>290</td>
      <td>6</td>
      <td>Est</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Recommandations basées sur les analyses
recommandations = """
4. Recommandations et Optimisations 🚀

Mohamed : "Enfin, basons-nous sur ces analyses pour proposer des recommandations. Voici ce que je suggère :"

1. **Réduire les délais de livraison** en optimisant les processus logistiques, notamment en travaillant avec des transporteurs plus rapides ou en ajustant les horaires de préparation des commandes.
2. **Améliorer le taux de service client** en analysant de manière plus détaillée les causes des retards et en mettant en place des actions correctives.
3. **Mettre en place un système d'alerte** pour identifier rapidement les commandes à risque de retard, afin d'intervenir avant que le délai de livraison soit dépassé.
4. **Optimiser la gestion des stocks** en se basant sur les tendances de ventes saisonnières pour éviter les ruptures de stock et les surstocks.
5. **Améliorer la communication inter-départements** pour une meilleure coordination entre les équipes de vente, logistique et approvisionnement.
"""
```


```python
# Affichage des recommandations
print(recommandations)
```

    
    4. Recommandations et Optimisations 🚀
    
    Mohamed : "Enfin, basons-nous sur ces analyses pour proposer des recommandations. Voici ce que je suggère :"
    
    1. **Réduire les délais de livraison** en optimisant les processus logistiques, notamment en travaillant avec des transporteurs plus rapides ou en ajustant les horaires de préparation des commandes.
    2. **Améliorer le taux de service client** en analysant de manière plus détaillée les causes des retards et en mettant en place des actions correctives.
    3. **Mettre en place un système d'alerte** pour identifier rapidement les commandes à risque de retard, afin d'intervenir avant que le délai de livraison soit dépassé.
    4. **Optimiser la gestion des stocks** en se basant sur les tendances de ventes saisonnières pour éviter les ruptures de stock et les surstocks.
    5. **Améliorer la communication inter-départements** pour une meilleure coordination entre les équipes de vente, logistique et approvisionnement.
    
    


```python

```


```python

```


```python

```


```python

```


```python

```
